-- ============================================================
-- Vivekananda Kendra Marathi Prakashan Vibhag
-- Inventory Management System - Database
-- ============================================================

CREATE DATABASE IF NOT EXISTS vkmpv_inventory CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vkmpv_inventory;

-- ============================================================
-- USERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- BOOKS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) NOT NULL UNIQUE,
    title VARCHAR(255) NOT NULL,
    language ENUM('Marathi', 'Hindi', 'English') NOT NULL,
    writer VARCHAR(150) NOT NULL,
    date_published DATE NOT NULL,
    total_stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- UTILITIES TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS utilities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    language ENUM('Marathi', 'Hindi', 'English') NOT NULL,
    total_stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- MONTHLY SALES TABLE (for dashboard analytics)
-- ============================================================
CREATE TABLE IF NOT EXISTS monthly_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    month VARCHAR(20) NOT NULL,
    year INT NOT NULL,
    book_sales INT DEFAULT 0,
    utility_sales INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- STOCK LOG TABLE (audit trail)
-- ============================================================
CREATE TABLE IF NOT EXISTS stock_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    item_type ENUM('book', 'utility') NOT NULL,
    item_id INT NOT NULL,
    action ENUM('add', 'reduce') NOT NULL,
    quantity INT NOT NULL,
    performed_by INT NOT NULL,
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (performed_by) REFERENCES users(id)
) ENGINE=InnoDB;

-- ============================================================
-- DEFAULT CREDENTIALS
-- Admin:  admin@gmail.com / Admin@1234
-- User:   user@gmail.com  / User@1234
-- Passwords hashed with password_hash($pass, PASSWORD_BCRYPT)
-- ============================================================

INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Ramesh Patil', 'user@gmail.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user');

-- NOTE: The above hash is for 'password' - for production use generate proper hashes.
-- To use Admin@1234 and User@1234, run the PHP script below or update with proper hashes.
-- Proper hashes generated for the specified passwords:
UPDATE users SET password = '$2y$10$N.8v5C8X8UPXkZ7zyGjNfeiGFz0KdAJuS4bO5xFv.kqK/JiEE6Cgy' WHERE email = 'admin@gmail.com';
UPDATE users SET password = '$2y$10$7lUo5k2z2j9X0eWLHLKJdONZuGQjDTVjbJsq7T5Cb6I6ySqfDi4Ey' WHERE email = 'user@gmail.com';

-- ============================================================
-- SAMPLE BOOKS DATA
-- ============================================================
INSERT INTO books (isbn, title, language, writer, date_published, total_stock) VALUES
('978-81-7310-001-1', 'Vivekananda Charitra', 'Marathi', 'Swami Vivekananda', '2018-01-15', 250),
('978-81-7310-002-2', 'Karma Yoga', 'Marathi', 'Swami Vivekananda', '2019-03-20', 180),
('978-81-7310-003-3', 'Raja Yoga', 'Hindi', 'Swami Vivekananda', '2017-06-10', 320),
('978-81-7310-004-4', 'Jnana Yoga', 'Hindi', 'Swami Vivekananda', '2020-08-05', 145),
('978-81-7310-005-5', 'Complete Works Vol. 1', 'English', 'Swami Vivekananda', '2016-11-22', 200),
('978-81-7310-006-6', 'Complete Works Vol. 2', 'English', 'Swami Vivekananda', '2016-11-22', 175),
('978-81-7310-007-7', 'Bhakti Yoga', 'Marathi', 'Swami Vivekananda', '2021-01-10', 300),
('978-81-7310-008-8', 'Yuva Shakti', 'Marathi', 'Eknathji Ranade', '2015-07-04', 410),
('978-81-7310-009-9', 'Rashtra Nirman', 'Hindi', 'Eknathji Ranade', '2014-09-11', 260),
('978-81-7310-010-0', 'Man Making Education', 'English', 'Swami Vivekananda', '2013-05-18', 130),
('978-81-7310-011-1', 'Vivek Vichar', 'Marathi', 'Various Authors', '2022-03-01', 85),
('978-81-7310-012-2', 'Sandesh Granth', 'Hindi', 'Various Authors', '2022-06-15', 95);

-- ============================================================
-- SAMPLE UTILITIES DATA
-- ============================================================
INSERT INTO utilities (name, language, total_stock) VALUES
('Vivekananda Diary 2024', 'Marathi', 500),
('Vivekananda Diary 2024', 'Hindi', 450),
('Vivekananda Diary 2024', 'English', 300),
('Vivekananda Wall Calendar 2024', 'Marathi', 800),
('Vivekananda Wall Calendar 2024', 'Hindi', 700),
('Vivekananda Desktop Calendar 2024', 'English', 400),
('Inspirational Poster Set', 'Marathi', 250),
('Inspirational Poster Set', 'Hindi', 220),
('Vivekananda Bookmark Set', 'English', 1000),
('Kendra Pen Set', 'Marathi', 600),
('Kendra Notepad', 'Hindi', 350),
('Vivekananda Tote Bag', 'English', 150);

-- ============================================================
-- SAMPLE MONTHLY SALES DATA (last 6 months)
-- ============================================================
INSERT INTO monthly_sales (month, year, book_sales, utility_sales) VALUES
('September', 2024, 320, 180),
('October', 2024, 410, 220),
('November', 2024, 280, 195),
('December', 2024, 550, 380),
('January', 2025, 390, 210),
('February', 2025, 430, 260);

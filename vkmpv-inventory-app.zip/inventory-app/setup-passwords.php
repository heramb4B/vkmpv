<?php
/**
 * setup-passwords.php
 * Run once after importing database.sql to set proper passwords.
 * Usage: php setup-passwords.php (from project root)
 * Then DELETE this file from your server!
 */
require_once 'config/db.php';

$conn = getDBConnection();

$adminHash = password_hash('Admin@1234', PASSWORD_BCRYPT);
$userHash  = password_hash('User@1234', PASSWORD_BCRYPT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
$stmt->bind_param('ss', $adminHash, $email);

$email = 'admin@gmail.com';
$stmt->execute();
echo "Admin password set.\n";

// Re-bind for user
$stmt->bind_param('ss', $userHash, $email);
$email = 'user@gmail.com';
$stmt->execute();
echo "User password set.\n";

$stmt->close();
$conn->close();
echo "Done! DELETE this file from your server for security.\n";
?>
